<?php
    class response{
    }
    $_response= new response;
    $_response->success = true;
    $_response->data= new response;
?>